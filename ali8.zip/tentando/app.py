from flask import Flask, render_template, request, redirect, url_for
import uuid

app = Flask(__name__)
atividades = []

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        atividade = {
            "id": str(uuid.uuid4()),  # ID único
            "materia": request.form["materia"],
            "data": request.form["data"],
            "horario": request.form["horario"],
            "prioridade": request.form["prioridade"],
            "comentario": request.form["comentario"],
            "status": "Pendente"  # status padrão
        }
        atividades.append(atividade)
    def prioridade_valor(p):
        return {"Alta": 0, "Média": 1, "Baixa": 2}.get(p, 3)

    atividades.sort(key=lambda x: (x["data"], prioridade_valor(x["prioridade"])))
    return render_template("index.html", atividades=atividades)

@app.route("/delete/<id>")
def delete(id):
    global atividades
    atividades = [a for a in atividades if a["id"] != id]
    return redirect(url_for("index"))

@app.route("/edit/<id>", methods=["GET", "POST"])
def edit(id):
    atividade = next((a for a in atividades if a["id"] == id), None)
    if not atividade:
        return redirect(url_for("index"))

    if request.method == "POST":
        atividade["materia"] = request.form["materia"]
        atividade["data"] = request.form["data"]
        atividade["horario"] = request.form["horario"]
        atividade["prioridade"] = request.form["prioridade"]
        atividade["comentario"] = request.form["comentario"]
        return redirect(url_for("index"))

    return render_template("secunt.html", atividade=atividade)

@app.route("/concluir/<id>")
def concluir(id):
    atividade = next((a for a in atividades if a["id"] == id), None)
    if atividade:
        atividade["status"] = "Concluída"
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
